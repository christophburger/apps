import control.Window;
import data.Plugin;


public class AppsPlugin implements Plugin {

	private final String PLUGINNAME = "Testplugin";
	
	public static void main(String[] args) {
		new AppsPlugin().run();
	}
	
	@Override
	public void run() {
		System.out.println("testplugin");
		new Window();
	}
	
	@Override
	public String getPluginName() {
		return PLUGINNAME;
	}

}
