package control;

import javax.swing.JFrame;

public class Window extends JFrame {

	public Window() {
		
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		
		setVisible(true);
	}
	
}
