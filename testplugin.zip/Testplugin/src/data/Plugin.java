package data;

public interface Plugin {
	
	public void run();
	public String getPluginName();
	
}
